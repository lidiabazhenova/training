package com.catalog;

import com.catalog.carpark.*;
import org.junit.Ignore;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class ExampleTest {

    @Test
    public void carParkList() {
        CarPark carPark = new CarPark();
        carPark.add(new Car(123000, "Audi", "A6 ", 5212, 3, "sedan"));
        carPark.add(new Car(123001, "Audi", "A4 ", 5212, 2, "sedan"));
        carPark.add(new TiltCoveredTruck(123214, "Volvo", "FH-90", 34000, "Smitz", "SM1234", 20, 86, true, true));
        carPark.add(new Refrigerator(177777, "Volvo", "FH-80", 34000, "Smitz", "SM1234", 20, 86, -20, 20));

        Car carForSale = new Car(123001, "Audi", "A4 ", 5212, 2, "sedan");
        carPark.sell(carForSale);

        carPark.printList();


    }

}



