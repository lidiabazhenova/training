package com.catalog.carpark;

public abstract class Truck extends Automobile {

    private String trailerBrand;
    private String trailerModel;
    private int carrying;
    private int volumeOfCargo;

    public Truck(long id, String brand, String model, double price, String trailerBrand, String trailerModel, int carrying, int volumeOfCargo) {
        super(id, brand, model, price);
        this.trailerBrand = trailerBrand;
        this.trailerModel = trailerModel;
        this.carrying = carrying;
        this.volumeOfCargo = volumeOfCargo;
    }

    public String getDescription() {
        return super.getDescription()
                + "TrailerBrand: " + trailerBrand + "\r\n "
                + "TrailerModel: " + trailerModel + "\r\n "
                + "Carrying: " + carrying + "\r\n "
                + "VolumeOfCargo: " + volumeOfCargo + "\r\n ";
    }

    public String getTrailerBrand() {
        return trailerBrand;
    }

    public void setTrailerBrand(String trailerBrand) {
        this.trailerBrand = trailerBrand;
    }

    public String getTrailerModel() {
        return trailerModel;
    }

    public void setTrailerModel(String trailerModel) {
        this.trailerModel = trailerModel;
    }

    public int getCarrying() {
        return carrying;
    }

    public void setCarrying(int carrying) {
        this.carrying = carrying;
    }

    public int getVolumeOfCargo() {
        return volumeOfCargo;
    }

    public void setVolumeOfCargo(int volumeOfCargo) {
        this.volumeOfCargo = volumeOfCargo;
    }
}
