package com.catalog.carpark;

public class TiltCoveredTruck extends Truck {

    private boolean sideLoading;
    private boolean topLoading;

    public TiltCoveredTruck(long id, String brand, String model, double price, String trailerBrand, String trailerModel, int carrying, int volumeOfCargo, boolean sideLoading, boolean topLoading) {
        super(id, brand, model, price, trailerBrand, trailerModel, carrying, volumeOfCargo);
        this.sideLoading = sideLoading;
        this.topLoading = topLoading;
    }

    public String getDescription() {
        return super.getDescription()
                + "SideLoading: " + sideLoading + "\r\n "
                + "TopLoading: " + topLoading + "\r\n ";
    }

    public boolean isSideLoading() {
        return sideLoading;
    }

    public void setSideLoading(boolean sideLoading) {
        this.sideLoading = sideLoading;
    }

    public boolean isTopLoading() {
        return topLoading;
    }

    public void setTopLoading(boolean topLoading) {
        this.topLoading = topLoading;
    }
}
