package com.catalog.carpark;

import java.util.ArrayList;
import java.util.List;

public class CarPark {
    private List<Automobile> automobiles;

    public CarPark() {
        automobiles = new ArrayList<Automobile>();
    }

    public List<Automobile> getAutomobiles() {
        return automobiles;
    }

    public void add(Automobile automobile) {
        automobiles.add(automobile);
    }

    public void sell(Automobile automobile) {
        automobiles.remove(automobile);
    }

    public void printList() {
        for (Automobile car : automobiles) {
            System.out.println(car.getDescription());
            System.out.println("***************");
        }
    }

}
