package com.catalog.carpark;

public class Car extends Automobile {

    int bootVolume;
    String bodywork;

    public Car(long id, String brand, String model, double price, int bootVolume, String bodywork) {
        super(id, brand, model, price);
        this.bootVolume = bootVolume;
        this.bodywork = bodywork;
    }

    public String getDescription() {
        return super.getDescription()
                + "BootVolume: " + bootVolume + "\r\n "
                + "Bodywork: " + bodywork + "\r\n ";

    }

    public int getBootVolume() {
        return bootVolume;
    }

    public void setBootVolume(int bootVolume) {
        this.bootVolume = bootVolume;
    }

    public String getBodywork() {
        return bodywork;
    }

    public void setBodywork(String bodywork) {
        this.bodywork = bodywork;
    }
}
