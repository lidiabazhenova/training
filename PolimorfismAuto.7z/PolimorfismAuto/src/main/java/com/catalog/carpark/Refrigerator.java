package com.catalog.carpark;

public class Refrigerator extends Truck {

    private int lowTemperatureRegime;
    private int highTemperatureRegime;

    public Refrigerator(long id, String brand, String model, double price, String trailerBrand, String trailerModel, int carrying, int volumeOfCargo, int lowTemperatureRegime, int highTemperatureRegime) {
        super(id, brand, model, price, trailerBrand, trailerModel, carrying, volumeOfCargo);
        this.lowTemperatureRegime = lowTemperatureRegime;
        this.highTemperatureRegime = highTemperatureRegime;
    }

    public String getDescription() {
        return super.getDescription()
                + "LowTemperatureRegime: " + lowTemperatureRegime + "\r\n "
                + "HighTemperatureRegime: " + highTemperatureRegime + "\r\n ";
    }

    public int getLowTemperatureRegime() {
        return lowTemperatureRegime;
    }

    public void setLowTemperatureRegime(int lowTemperatureRegime) {
        this.lowTemperatureRegime = lowTemperatureRegime;
    }

    public int getHighTemperatureRegime() {
        return highTemperatureRegime;
    }

    public void setHighTemperatureRegime(int highTemperatureRegime) {
        this.highTemperatureRegime = highTemperatureRegime;
    }
}


