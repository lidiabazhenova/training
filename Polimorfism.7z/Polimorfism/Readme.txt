Inheritance:
Book, MobilePhone, Dress i.e. extends Product;
*****

Encapsulation:
1. private fields in classes Product, Book, MobilePhone, Dress + setters and getters;
2. private constructor for Book and MobilePhone + createItem();
*****

Polimorfism:
1. overriding
  ***Book, MobilePhone, Dress override getDetails() from Product 
2. overloading
  ***Book, MobilePhone, Dress overload createItem() and constructors with/without args
*****

Examples in ExampleTest
*****
